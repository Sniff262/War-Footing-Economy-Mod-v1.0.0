@echo off
rem Finds the War Footing folder and runs installer.js on the game's own executable.
rem Usage: run.cmd install^|uninstall^|status   (no argument: status)
setlocal EnableExtensions DisableDelayedExpansion
set "ACTION=%~1"
if not defined ACTION set "ACTION=status"
set "MODDIR=%~dp0"
set "GAME="
set "RC=1"
set "TRIES=0"

rem 0) Set WARFOOTING_DIR to pick the game folder yourself.
if defined WARFOOTING_DIR set "GAME=%WARFOOTING_DIR:"=%"
if defined GAME goto :found

rem 1) The mod was extracted into the game folder, or into a folder (or two) inside it.
for %%I in ("%MODDIR%..") do if exist "%%~fI\War Footing.exe" set "GAME=%%~fI"
if not defined GAME for %%I in ("%MODDIR%..\..") do if exist "%%~fI\War Footing.exe" set "GAME=%%~fI"
if not defined GAME for %%I in ("%MODDIR%..\..\..") do if exist "%%~fI\War Footing.exe" set "GAME=%%~fI"
if defined GAME goto :found

rem 2) Ask Steam where the game is installed (UTF-8, so non-English folder names survive).
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell.exe"
set "OLDCP="
for /f "tokens=2 delims=:." %%C in ('chcp ^<nul') do set "OLDCP=%%C"
chcp 65001 <nul >nul 2>&1
for /f "usebackq delims=" %%G in (`^""%PS%" -NoProfile -ExecutionPolicy Bypass -File "%MODDIR%find_game.ps1" 2^>nul ^<nul^"`) do set "GAME=%%G"
if defined OLDCP chcp %OLDCP: =% <nul >nul 2>&1
if defined GAME if not exist "%GAME%\War Footing.exe" set "GAME="
if defined GAME if not exist "%GAME%\resources\app.asar" set "GAME="
if defined GAME goto :found

rem 3) Ask the player.
echo Could not find War Footing automatically.
echo In Steam: right-click War Footing ^> Manage ^> Browse local files.
echo Drag "War Footing.exe" (or the folder it is in) into this window, or paste its path, then press Enter.
echo (Dragging does not work in a window started as administrator: paste the path instead.)
:ask
set /a TRIES+=1
set "GAME="
echo.
set /p "GAME=War Footing folder: "
if not defined GAME goto :noanswer
set "GAME=%GAME:"=%"
call :tidy
if not defined GAME goto :noanswer
if exist "%GAME%\War Footing.exe" if exist "%GAME%\resources\app.asar" goto :found
echo "%GAME%" is not the War Footing folder: it needs "War Footing.exe" and "resources\app.asar".
if %TRIES% LSS 3 goto :ask
set "RC=1"
goto :done

:found
if not defined GAME goto :nogame
set "GAME=%GAME:"=%"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"
if not exist "%GAME%\War Footing.exe" goto :nogame
if not exist "%GAME%\resources\app.asar" goto :nogame

set "NODE_OPTIONS="
set "NODE_PATH="
set "ELECTRON_RUN_AS_NODE=1"
"%GAME%\War Footing.exe" "%MODDIR%installer.js" %ACTION% "%GAME%" <nul
set "RC=%ERRORLEVEL%"
if not "%RC%"=="3" goto :checkrc

echo.
choice /C YN /M "Install anyway"
if errorlevel 2 goto :cancelled
"%GAME%\War Footing.exe" "%MODDIR%installer.js" %ACTION% "%GAME%" --force <nul
set "RC=%ERRORLEVEL%"

:checkrc
if "%RC%"=="0" goto :done
if "%RC%"=="1" goto :done
if "%RC%"=="2" goto :done
if "%RC%"=="3" goto :done
echo The installer could not start (exit code %RC%). Make sure the game's files are complete: Steam ^> right-click War Footing ^> Properties ^> Installed Files ^> Verify integrity of game files. Then try again.
goto :done

:cancelled
echo Nothing was changed.
set "RC=0"
goto :done

:noanswer
echo No folder entered. Nothing was changed.
set "RC=1"
goto :done

:nogame
echo.
if defined GAME echo "%GAME%" is not the War Footing folder: it needs "War Footing.exe" and "resources\app.asar".
echo In Steam: right-click War Footing ^> Manage ^> Browse local files to find it.
set "RC=1"

:done
set "ELECTRON_RUN_AS_NODE="
echo.
pause
exit /b %RC%

rem Clean up a typed or dragged answer: spaces, trailing backslashes,
rem War Footing.exe instead of its folder, or the resources folder.
:tidy
for /f "tokens=* delims= " %%A in ("%GAME%") do set "GAME=%%A"
:tidytrail
if not defined GAME exit /b 0
if "%GAME:~-1%"==" " set "GAME=%GAME:~0,-1%" & goto :tidytrail
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%" & goto :tidytrail
if not defined GAME exit /b 0
if exist "%GAME%" if not exist "%GAME%\*" for %%I in ("%GAME%") do set "GAME=%%~dpI"
if "%GAME:~-1%"=="\" set "GAME=%GAME:~0,-1%"
for %%I in ("%GAME%") do if /i "%%~nxI"=="resources" for %%J in ("%GAME%\..") do set "GAME=%%~fJ"
exit /b 0
