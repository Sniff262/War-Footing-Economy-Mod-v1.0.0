# Prints the War Footing install folder if Steam knows where it is. Reads only.
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$appId = '4727860'

function Test-Game($dir) {
    (Test-Path -LiteralPath (Join-Path $dir 'War Footing.exe')) -and (Test-Path -LiteralPath (Join-Path $dir 'resources\app.asar'))
}

$steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam').SteamPath
if (-not $steam) { $steam = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam').InstallPath }
if (-not $steam) { $steam = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Valve\Steam').InstallPath }
if (-not $steam) { exit 1 }
$steam = $steam -replace '/', '\'

# Steam libraries: the main one plus every entry in libraryfolders.vdf (UTF-8, no BOM).
$libraries = @($steam)
$vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
if (Test-Path -LiteralPath $vdf) {
    $text = Get-Content -LiteralPath $vdf -Raw -Encoding UTF8
    # current format: "path" "D:\\SteamLibrary"; pre-2021 format: "1" "D:\\SteamLibrary"
    foreach ($m in [regex]::Matches($text, '"(?:path|\d+)"\s+"([^"]+)"')) {
        $value = $m.Groups[1].Value -replace '\\\\', '\'
        if ($value -match '^[A-Za-z]:\\|^\\\\') { $libraries += $value }
    }
}
$libraries = $libraries | Select-Object -Unique

# Pass 1: the library whose app manifest says War Footing is installed there.
foreach ($lib in $libraries) {
    $acf = Join-Path $lib "steamapps\appmanifest_$appId.acf"
    if (-not (Test-Path -LiteralPath $acf)) { continue }
    $m = [regex]::Match((Get-Content -LiteralPath $acf -Raw -Encoding UTF8), '"installdir"\s+"([^"]+)"')
    if (-not $m.Success) { continue }
    $dir = Join-Path $lib ('steamapps\common\' + $m.Groups[1].Value)
    if (Test-Game $dir) { Write-Output $dir; exit 0 }
}

# Pass 2: the default folder name in any library.
foreach ($lib in $libraries) {
    $dir = Join-Path $lib 'steamapps\common\War Footing'
    if (Test-Game $dir) { Write-Output $dir; exit 0 }
}
exit 1
