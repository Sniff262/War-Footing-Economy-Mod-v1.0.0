'use strict';
/*
 * War Footing - Economy & Exports Mod: installer / uninstaller.
 *
 * The .bat files run this on the game's own executable in Node mode, so players
 * need nothing else installed:
 *     set ELECTRON_RUN_AS_NODE=1
 *     "War Footing.exe" installer.js install|uninstall|status "<game folder>" [--force]
 * Any Node.js 16+ runs it too (Linux / Steam Deck):
 *     node installer.js install "/path/to/War Footing"
 *
 * The mod does not ship the game's files. patch.json holds only the mod's own
 * edits (each with a few lines of the surrounding game code, so it can find its
 * place) plus the files the mod adds. Install applies them to your copy of
 * resources/app.asar after backing that file up; uninstall puts the backup back.
 *
 * Exit codes: 0 done (or nothing to do), 1 failed - nothing was changed,
 * 2 the game is running, 3 the game files differ from the version the mod was
 * made for - run again with --force to install anyway.
 */

process.noAsar = true; // Electron: treat app.asar as a plain file, not a folder
let fs;
try { fs = require('original-fs'); } catch (e) { fs = require('fs'); }
const path = require('path');
const crypto = require('crypto');

const EXIT = { OK: 0, FAIL: 1, RUNNING: 2, NEEDS_FORCE: 3 };
const BACKUP_NAME = 'app.asar.economy-mod-backup';
const STAMP_NAME = 'economy-mod-install.json';
const TMP_SUFFIX = '.economy-mod-tmp';
const GAME_EXE = 'War Footing.exe';
const VERIFY_HINT = 'In Steam: right-click War Footing > Properties > Installed Files > "Verify integrity of game files". That restores the original game.';

class Abort extends Error {
    constructor(message, code = EXIT.FAIL) { super(message); this.code = code; }
}

const say = (...a) => console.log(...a);
const sha256 = buf => crypto.createHash('sha256').update(buf).digest('hex');

function sha256File(file) {
    const h = crypto.createHash('sha256');
    const fd = fs.openSync(file, 'r');
    try {
        const buf = Buffer.alloc(1 << 20);
        let n;
        while ((n = fs.readSync(fd, buf, 0, buf.length, null)) > 0) h.update(buf.subarray(0, n));
    } finally { fs.closeSync(fd); }
    return h.digest('hex');
}

function sleep(ms) { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); }

function removeQuietly(file) { try { fs.unlinkSync(file); } catch (e) { /* not there */ } }

// ─── Electron archive (asar) ────────────────────────────────────────────────

function openAsar(file) {
    let fd;
    try { fd = fs.openSync(file, 'r'); } catch (e) { throw new Abort(`Could not open ${file}: ${e.message}`); }
    try {
        const sizePickle = Buffer.alloc(8);
        if (fs.readSync(fd, sizePickle, 0, 8, 0) !== 8) throw new Error('file is too short');
        const headerSize = sizePickle.readUInt32LE(4);
        const headerPickle = Buffer.alloc(headerSize);
        if (fs.readSync(fd, headerPickle, 0, headerSize, 8) !== headerSize) throw new Error('header is cut short');
        const jsonLength = headerPickle.readUInt32LE(4);
        const header = JSON.parse(headerPickle.toString('utf8', 8, 8 + jsonLength));
        if (!header || typeof header.files !== 'object') throw new Error('no file table');
        return { file, fd, header, base: 8 + headerSize };
    } catch (e) {
        fs.closeSync(fd);
        throw new Abort(`${file} is not a readable game archive (${e.message}). ${VERIFY_HINT}`);
    }
}

function closeAsar(a) {
    if (a && a.fd !== null) { fs.closeSync(a.fd); a.fd = null; }
}

function entryAt(header, p) {
    let node = header;
    for (const part of p.split('/')) {
        if (!node.files || !Object.prototype.hasOwnProperty.call(node.files, part)) return null;
        node = node.files[part];
    }
    return node;
}

function readEntry(a, e) {
    if (e.files || e.unpacked || e.link !== undefined) throw new Abort('Unexpected archive entry (folder, link or unpacked file).');
    const size = Number(e.size) || 0;
    const buf = Buffer.alloc(size);
    let got = 0;
    while (got < size) {
        const n = fs.readSync(a.fd, buf, got, size - got, a.base + Number(e.offset) + got);
        if (n <= 0) throw new Abort(`${a.file} is truncated. ${VERIFY_HINT}`);
        got += n;
    }
    return buf;
}

const BLOCK = 4 * 1024 * 1024;
function integrity(buf) {
    const blocks = [];
    for (let i = 0; i < Math.max(buf.length, 1); i += BLOCK) blocks.push(sha256(buf.subarray(i, i + BLOCK)));
    return { algorithm: 'SHA256', hash: sha256(buf), blockSize: BLOCK, blocks };
}

/** Every packed file in archive order: { path, entry }. */
function packedFiles(header) {
    const out = [];
    (function walk(node, rel) {
        for (const name of Object.keys(node.files || {})) {
            const e = node.files[name];
            const p = rel ? `${rel}/${name}` : name;
            if (e.files) walk(e, p);
            else if (!e.unpacked && e.link === undefined) out.push({ path: p, entry: e });
        }
    })(header, '');
    return out;
}

function writeAll(fd, buf) {
    let done = 0;
    while (done < buf.length) done += fs.writeSync(fd, buf, done, buf.length - done);
}

/**
 * Write a copy of archive `src` to outFile with `changes` applied:
 * path -> Buffer replaces or adds a file, path -> null removes it.
 * Unchanged files are copied byte for byte; unpacked files stay where they are.
 */
function writeAsar(src, changes, outFile) {
    const header = JSON.parse(JSON.stringify(src.header));
    for (const [p, buf] of changes) {
        if (buf === null || entryAt(header, p)) continue;
        const parts = p.split('/');
        let node = header;
        for (const dir of parts.slice(0, -1)) {
            if (!node.files[dir]) node.files[dir] = { files: {} };
            node = node.files[dir];
            if (!node.files) throw new Abort(`Cannot add ${p}: ${dir} is a file in the archive.`);
        }
        node.files[parts[parts.length - 1]] = { size: 0, offset: '0' };
    }
    for (const [p, buf] of changes) {
        if (buf !== null) continue;
        const parts = p.split('/');
        const parent = parts.length > 1 ? entryAt(header, parts.slice(0, -1).join('/')) : header;
        if (parent && parent.files) delete parent.files[parts[parts.length - 1]];
    }

    const jobs = [];
    let offset = 0;
    for (const { path: p, entry } of packedFiles(header)) {
        const data = changes.get(p);
        const size = data ? data.length : Number(entry.size) || 0;
        jobs.push({ path: p, data: data || null, source: data ? null : entryAt(src.header, p) });
        entry.size = size;
        entry.offset = String(offset);
        if (data) entry.integrity = integrity(data);
        offset += size;
    }

    const json = Buffer.from(JSON.stringify(header), 'utf8');
    const pad = (4 - (json.length % 4)) % 4;
    const headerPickle = Buffer.alloc(8 + json.length + pad);
    headerPickle.writeUInt32LE(4 + json.length + pad, 0);
    headerPickle.writeUInt32LE(json.length, 4);
    json.copy(headerPickle, 8);
    const sizePickle = Buffer.alloc(8);
    sizePickle.writeUInt32LE(4, 0);
    sizePickle.writeUInt32LE(headerPickle.length, 4);

    const fd = fs.openSync(outFile, 'w');
    try {
        writeAll(fd, sizePickle);
        writeAll(fd, headerPickle);
        for (const j of jobs) writeAll(fd, j.data || readEntry(src, j.source));
        fs.fsyncSync(fd);
    } finally { fs.closeSync(fd); }
    return jobs;
}

/** Re-read the written archive and check every file against what was meant to go in. */
function verifyAsar(src, jobs, outFile) {
    const out = openAsar(outFile);
    try {
        const files = packedFiles(out.header);
        if (files.length !== jobs.length) throw new Abort('The rebuilt archive has the wrong number of files. Nothing was changed.');
        for (let i = 0; i < jobs.length; i++) {
            const j = jobs[i];
            if (files[i].path !== j.path) throw new Abort(`The rebuilt archive is out of order at ${j.path}. Nothing was changed.`);
            const want = j.data || readEntry(src, j.source);
            if (!want.equals(readEntry(out, files[i].entry))) throw new Abort(`The rebuilt archive does not match at ${j.path}. Nothing was changed.`);
        }
    } finally { closeAsar(out); }
}

// ─── Text patches ───────────────────────────────────────────────────────────

function linesMatch(lines, block, at) {
    if (at < 0 || at + block.length > lines.length) return false;
    for (let k = 0; k < block.length; k++) if (lines[at + k] !== block[k]) return false;
    return true;
}

/**
 * Apply hunks (each: the old lines with a little context, and what replaces them).
 * `exact`: the file is byte-identical to the one the patch was made from, so every
 * hunk must sit exactly where it was recorded. Otherwise a hunk may have moved,
 * but its lines must then appear exactly once further down the file.
 * Returns the new text, or null with `why` filled in.
 */
function applyHunks(text, hunks, reverse, exact, why) {
    const lines = text.split('\n');
    let delta = 0;
    let from = 0;
    for (let n = 0; n < hunks.length; n++) {
        const h = hunks[n];
        const find = reverse ? h.b : h.a;
        const put = reverse ? h.a : h.b;
        const recorded = reverse ? h.bStart : h.aStart;
        const expected = recorded + delta;
        let pos = -1;
        if (expected >= from && linesMatch(lines, find, expected)) pos = expected;
        else if (!exact && find.length > 0) {
            const hits = [];
            for (let i = from; i + find.length <= lines.length && hits.length < 2; i++) {
                if (linesMatch(lines, find, i)) hits.push(i);
            }
            if (hits.length === 1) pos = hits[0];
            else why.push(`edit ${n + 1} of ${hunks.length} (around line ${expected + 1}): ${hits.length ? 'matches more than one place' : 'the game code there has changed'}`);
        } else {
            why.push(`edit ${n + 1} of ${hunks.length} (line ${expected + 1}) does not fit`);
        }
        if (pos < 0) return null;
        lines.splice(pos, find.length, ...put);
        delta = pos - recorded + put.length - find.length;
        from = pos + put.length;
    }
    return lines.join('\n');
}

// ─── Mod state ──────────────────────────────────────────────────────────────

function loadManifest() {
    const file = path.join(__dirname, 'patch.json');
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) {
        throw new Abort(`Could not read ${file} (${e.message}). Download the mod again and extract the whole zip.`);
    }
}

function updateHint(manifest) {
    return manifest.homepage
        ? `Check ${manifest.homepage} for an update.`
        : 'Check the forum thread you downloaded the mod from for an update.';
}

function gameVersionOf(a) {
    try { return JSON.parse(readEntry(a, entryAt(a.header, 'package.json')).toString('utf8')).version || '?'; } catch (e) { return '?'; }
}

/** Where each file the mod touches stands in an archive. */
function analyze(a, manifest) {
    const files = manifest.files.map(f => {
        const e = entryAt(a.header, f.path);
        if (!e || e.files || e.unpacked || e.link !== undefined) return { f, state: 'missing', entry: e };
        const buf = readEntry(a, e);
        const sha = sha256(buf);
        const state = sha === f.moddedSha256 ? 'modded' : (f.op === 'patch' && sha === f.vanillaSha256 ? 'vanilla' : 'changed');
        return { f, state, entry: e, buf, sha };
    });
    const adds = files.filter(x => x.f.op === 'add');
    return {
        files,
        allModded: files.every(x => x.state === 'modded'),
        modPresent: adds.some(x => x.state !== 'missing'),
        version: gameVersionOf(a),
    };
}

function stampPath(p) { return path.join(p.resources, STAMP_NAME); }

function readStamp(p) {
    try { return JSON.parse(fs.readFileSync(stampPath(p), 'utf8')); } catch (e) { return null; }
}

/** Clear the read-only attribute (Windows) / add owner write permission. */
function makeWritable(file) {
    try { fs.chmodSync(file, (fs.statSync(file).mode & 0o777) | 0o200); } catch (e) { /* best effort */ }
}

function isReadOnly(file) {
    try { return (fs.statSync(file).mode & 0o200) === 0; } catch (e) { return false; }
}

/** Run a file-system step; turn the usual Windows failures into plain advice. */
function fsStep(what, fn) {
    try { return fn(); } catch (e) {
        if (e instanceof Abort) throw e;
        if (e && e.code === 'ENOSPC') throw new Abort(`Not enough free disk space to ${what}. The installer needs about 130 MB free on the game's drive. Nothing was changed.`);
        if (e && ['EPERM', 'EACCES', 'EBUSY'].includes(e.code)) {
            throw new Abort(`Windows would not let the installer ${what} (${e.code}). Make sure War Footing is closed and any Steam update or file check has finished, then try again. If it keeps happening, check whether your antivirus blocked it. Nothing was changed.`);
        }
        throw e;
    }
}

/**
 * The backup made when the mod was installed, if it can be trusted: its hash is
 * the one recorded then, and the live archive is still that install - either
 * byte-identical, or still carrying the mod's own added files (e.g. the player
 * tuned some numbers afterwards). A Steam update or verify replaces the archive
 * and removes the mod's files, which ends the trust.
 */
function trustedBackup(p, stamp, liveSha, live) {
    if (!stamp || !stamp.backupSha256 || !fs.existsSync(p.backup)) return null;
    const exact = stamp.installedSha256 === liveSha;
    let ownFiles = false;
    if (!exact && stamp.addedSha256 && Object.keys(stamp.addedSha256).length) {
        ownFiles = Object.entries(stamp.addedSha256).every(([file, sha]) => {
            const e = entryAt(live.header, file);
            return e && !e.files && !e.unpacked && e.link === undefined && sha256(readEntry(live, e)) === sha;
        });
    }
    if (!exact && !ownFiles) return null;
    if (sha256File(p.backup) !== stamp.backupSha256) return null;
    return { exact };
}

/** Is this copy of the game running? (Another copy elsewhere does not matter.) */
function gameIsRunning(gameDir) {
    if (process.platform !== 'win32') return false;
    const cp = require('child_process');
    const exe = path.resolve(gameDir, GAME_EXE).toLowerCase();
    try {
        const script = '[Console]::OutputEncoding = [Text.Encoding]::UTF8; '
            + `Get-CimInstance Win32_Process -Filter "Name='${GAME_EXE}'" | ForEach-Object { [string]$_.ProcessId + '|' + $_.ExecutablePath }`;
        const ps = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
        const out = cp.execFileSync(fs.existsSync(ps) ? ps : 'powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script],
            { encoding: 'utf8', windowsHide: true, timeout: 30000, stdio: ['ignore', 'pipe', 'ignore'] });
        return out.split(/\r?\n/).some(line => {
            const bar = line.indexOf('|');
            if (bar < 0) return false;
            const pid = Number(line.slice(0, bar));
            const exePath = line.slice(bar + 1).trim();
            if (!pid || pid === process.pid) return false;
            return !exePath || path.resolve(exePath).toLowerCase() === exe; // unknown path: assume it is this copy
        });
    } catch (e) { /* PowerShell unavailable: fall back to any process with the game's name */ }
    try {
        const out = cp.execFileSync('tasklist', ['/FI', `IMAGENAME eq ${GAME_EXE}`, '/FO', 'CSV', '/NH'], { encoding: 'utf8', windowsHide: true });
        return [...out.matchAll(/^"[^"]*","(\d+)"/gm)].some(m => Number(m[1]) !== process.pid);
    } catch (e) { return false; }
}

function replaceFile(tmp, target) {
    for (let attempt = 0; ; attempt++) {
        try { fs.renameSync(tmp, target); return; } catch (e) {
            if (['EPERM', 'EACCES'].includes(e.code) && isReadOnly(target)) {
                makeWritable(target);
                if (!isReadOnly(target) && attempt < 8) continue;
                removeQuietly(tmp);
                throw new Abort(`${target} is marked Read-only and the installer could not change that. Right-click it > Properties > untick "Read-only", then run this again. Nothing was changed.`);
            }
            if (attempt < 8 && ['EPERM', 'EBUSY', 'EACCES'].includes(e.code)) { sleep(400); continue; }
            removeQuietly(tmp);
            if (gameIsRunning(path.dirname(path.dirname(target)))) throw new Abort('War Footing is running. Close the game, then run this again. Nothing was changed.', EXIT.RUNNING);
            throw new Abort(`Windows would not let the installer replace ${target} (${e.code}). Make sure War Footing is closed and any Steam update or file check has finished, wait a minute, then try again. If it keeps happening, check whether your antivirus blocked the file. Nothing was changed.`);
        }
    }
}

/** Put the install-time backup back over app.asar and forget the install. */
function restoreBackup(p, stamp) {
    const restoreTmp = p.live + TMP_SUFFIX;
    fsStep('copy the backup', () => fs.copyFileSync(p.backup, restoreTmp));
    makeWritable(restoreTmp);
    if (sha256File(restoreTmp) !== stamp.backupSha256) { removeQuietly(restoreTmp); throw new Abort('Could not copy the backup reliably. Nothing was changed.'); }
    replaceFile(restoreTmp, p.live);
    removeQuietly(p.backup);
    removeQuietly(stampPath(p));
}

// ─── Commands ───────────────────────────────────────────────────────────────

function paths(gameDir) {
    const resources = path.join(gameDir, 'resources');
    const live = path.join(resources, 'app.asar');
    if (!fs.existsSync(live)) {
        throw new Abort(`No resources\\app.asar in "${gameDir}". That does not look like the War Footing folder (Steam: right-click War Footing > Manage > Browse local files).`);
    }
    return { resources, live, backup: path.join(resources, BACKUP_NAME), tmp: live + TMP_SUFFIX };
}

/** This exact install was made by this version of the mod (possibly adapted with --force). */
function installedByThisVersion(stamp, manifest, liveSha, st) {
    return st.modPresent && !!stamp && stamp.modVersion === manifest.modVersion && stamp.installedSha256 === liveSha;
}

function status(gameDir, manifest) {
    const p = paths(gameDir);
    const a = openAsar(p.live);
    try {
        const st = analyze(a, manifest);
        const stamp = readStamp(p);
        const liveSha = sha256File(p.live);
        say(`Game folder:  ${gameDir}`);
        say(`Game version: ${st.version} (this mod was made for ${manifest.gameVersion})`);
        if (st.allModded) say(`Mod:          ${manifest.modName} v${manifest.modVersion} is installed.`);
        else if (installedByThisVersion(stamp, manifest, liveSha, st)) say(`Mod:          ${manifest.modName} v${manifest.modVersion} is installed (adapted to your game files).`);
        else if (st.modPresent && stamp && stamp.modVersion === manifest.modVersion) say(`Mod:          v${manifest.modVersion} is installed, but some of its files were edited afterwards.`);
        else if (st.modPresent) say(`Mod:          a different version of the mod is installed${stamp && stamp.modVersion ? ` (v${stamp.modVersion})` : ''}.`);
        else say('Mod:          not installed.');
        say(`Backup:       ${fs.existsSync(p.backup) ? 'present' : 'none'}`);
    } finally { closeAsar(a); }
    return EXIT.OK;
}

function install(gameDir, manifest, force) {
    const p = paths(gameDir);
    if (gameIsRunning(gameDir)) throw new Abort('War Footing is running. Close the game, then run this again.', EXIT.RUNNING);
    removeQuietly(p.tmp);
    removeQuietly(p.backup + TMP_SUFFIX);
    const liveSha = sha256File(p.live);
    const stamp = readStamp(p);
    let live = openAsar(p.live);
    let base = null;
    try {
        const now = analyze(live, manifest);
        if (now.allModded || installedByThisVersion(stamp, manifest, liveSha, now)) {
            say(`${manifest.modName} v${manifest.modVersion} is already installed. Nothing to do.`);
            return EXIT.OK;
        }
        let baseFile = p.live;
        let baseState = now;
        let baseSha = liveSha;
        if (now.modPresent) {
            const trusted = trustedBackup(p, stamp, liveSha, live);
            if (!trusted) {
                throw new Abort(`Another version of the mod is installed, and the backup of the original game made when it was installed is missing or no longer matches.\n${VERIFY_HINT} Then run Install again.`);
            }
            if (stamp.modVersion === manifest.modVersion) {
                say(`${manifest.modName} v${manifest.modVersion} is already installed, but some of its files were edited after it was installed.`);
                say('To start fresh, run "Uninstall Economy Mod.bat" first, then install again.');
                return EXIT.OK;
            }
            // An older or newer version of the mod: rebuild from the clean backup taken at its install.
            say(`Replacing the previously installed version of the mod${stamp.modVersion ? ` (v${stamp.modVersion})` : ''}...`);
            closeAsar(live); live = null;
            base = openAsar(p.backup);
            baseFile = p.backup;
            baseSha = stamp.backupSha256;
            baseState = analyze(base, manifest);
            if (baseState.modPresent) throw new Abort(`The backup already contains a version of the mod. ${VERIFY_HINT} Then run Install again.`);
        } else {
            base = live; live = null;
        }

        const changes = new Map();
        const added = {};
        const problems = [];
        const inexact = [];
        for (const x of baseState.files) {
            const f = x.f;
            if (f.op === 'add') {
                const data = Buffer.from(f.content, 'utf8');
                if (sha256(data) !== f.moddedSha256) throw new Abort('mod\\patch.json is damaged. Download the mod again.');
                if (x.state !== 'missing') problems.push(`${f.path}: the game already has a file with this name`);
                changes.set(f.path, data);
                added[f.path] = f.moddedSha256;
                continue;
            }
            if (x.state === 'missing') { problems.push(`${f.path}: not found in the game`); continue; }
            const text = x.buf.toString('utf8');
            if (!Buffer.from(text, 'utf8').equals(x.buf)) { problems.push(`${f.path}: not a text file the patch can read`); continue; }
            const exact = x.state === 'vanilla';
            const why = [];
            const out = applyHunks(text, f.hunks, false, exact, why);
            if (out === null) { problems.push(`${f.path}: ${why.join('; ')}`); continue; }
            const data = Buffer.from(out, 'utf8');
            if (exact && sha256(data) !== f.moddedSha256) throw new Abort(`The patch did not apply cleanly to ${f.path}. Download the mod again. Nothing was changed.`);
            if (!exact) inexact.push(f.path);
            changes.set(f.path, data);
        }
        const sameVersion = baseState.version === manifest.gameVersion;
        if (problems.length) {
            throw new Abort([
                sameVersion
                    ? 'Parts of the game this mod edits are different in your copy (a game update, or another mod):'
                    : `War Footing ${baseState.version} changed parts of the game this mod edits (it was made for ${manifest.gameVersion}):`,
                ...problems.map(s => `  - ${s}`),
                `Nothing was changed. ${updateHint(manifest)}`
            ].join('\n'));
        }
        const untested = baseSha !== manifest.baseArchiveSha256 || !sameVersion;
        if ((inexact.length || untested) && !force) {
            say(sameVersion
                ? 'Your game files are not exactly the ones this mod was tested with (a quiet game update, or another mod).'
                : `Your game is version ${baseState.version}; this mod was made and tested for ${manifest.gameVersion}.`);
            say('All of the mod\'s edits still fit, so it will most likely work, but it has not been tested on your version.');
            if (inexact.length) {
                say('Files the mod had to fit around changes:');
                for (const f of inexact) say(`  - ${f}`);
            }
            return EXIT.NEEDS_FORCE;
        }

        say(`Building the modded game archive (${changes.size} files changed)...`);
        const jobs = fsStep('write the new game archive', () => writeAsar(base, changes, p.tmp));
        verifyAsar(base, jobs, p.tmp);

        // Back up the original game archive before replacing it (an upgrade keeps the existing backup).
        let backupSha = stamp && stamp.backupSha256;
        let createdBackup = false;
        closeAsar(base); base = null;
        if (baseFile === p.live) {
            const backupTmp = p.backup + TMP_SUFFIX;
            fsStep('back up the game archive', () => fs.copyFileSync(p.live, backupTmp));
            makeWritable(backupTmp);
            backupSha = sha256File(backupTmp);
            if (backupSha !== liveSha) { removeQuietly(backupTmp); throw new Abort('Could not make a reliable backup of the game archive. Nothing was changed.'); }
            replaceFile(backupTmp, p.backup);
            createdBackup = true;
        }
        const installedSha = sha256File(p.tmp);
        try {
            replaceFile(p.tmp, p.live);
        } catch (e) {
            if (createdBackup) removeQuietly(p.backup); // identical to the untouched live archive
            throw e;
        }
        try {
            fs.writeFileSync(stampPath(p), JSON.stringify({
                mod: manifest.modName,
                modVersion: manifest.modVersion,
                gameVersion: baseState.version,
                installedSha256: installedSha,
                backupSha256: backupSha,
                addedSha256: added,
                installedAt: new Date().toISOString(),
            }, null, 2));
        } catch (e) {
            say(`(Could not write ${STAMP_NAME}: ${e.code || e.message}. The mod is installed; Uninstall will undo its edits instead of using the backup.)`);
        }
        say('');
        say(`${manifest.modName} v${manifest.modVersion} installed. Start War Footing as usual.`);
        say('Your saves keep working. Read the Field Manual (? Help) in game for the new systems.');
        say(`The original game archive is backed up as resources\\${BACKUP_NAME}; Uninstall puts it back.`);
        return EXIT.OK;
    } finally {
        closeAsar(live);
        closeAsar(base);
        removeQuietly(p.tmp);
        removeQuietly(p.backup + TMP_SUFFIX);
    }
}

function uninstall(gameDir, manifest) {
    const p = paths(gameDir);
    if (gameIsRunning(gameDir)) throw new Abort('War Footing is running. Close the game, then run this again.', EXIT.RUNNING);
    removeQuietly(p.tmp);
    removeQuietly(p.backup + TMP_SUFFIX);
    const liveSha = sha256File(p.live);
    const stamp = readStamp(p);
    const live = openAsar(p.live);
    try {
        const st = analyze(live, manifest);

        if (!st.modPresent) {
            closeAsar(live);
            say('This mod is not installed.');
            const untouched = st.files.every(x => x.f.op === 'add' || x.state === 'vanilla');
            say(untouched
                ? 'The game files it edits are the original ones.'
                : `Some of the game files it edits differ from the original (a game update, or another mod). If the game misbehaves: ${VERIFY_HINT}`);
            // Leftovers: Steam replaced the archive since the install, or an install failed half-way.
            const leftover = fs.existsSync(p.backup) && (stamp ? stamp.installedSha256 !== liveSha : sha256File(p.backup) === liveSha);
            if (leftover) {
                removeQuietly(p.backup);
                say('Removed the mod\'s leftover backup file.');
            }
            if (stamp && stamp.installedSha256 !== liveSha) removeQuietly(stampPath(p));
            return EXIT.OK;
        }

        const trusted = trustedBackup(p, stamp, liveSha, live);
        if (trusted && trusted.exact) {
            closeAsar(live);
            restoreBackup(p, stamp);
            say('Mod removed: the original game archive is back. Your saves keep working.');
            return EXIT.OK;
        }

        // Undo the edits in place (keeps any unrelated changes made since).
        if (!trusted && !st.allModded && !(stamp && stamp.modVersion === manifest.modVersion)) {
            throw new Abort(`A different version of the mod is installed and its backup is missing, so this version cannot remove it.\n${VERIFY_HINT}`);
        }
        const changes = new Map();
        const problems = [];
        for (const x of st.files) {
            const f = x.f;
            if (f.op === 'add') {
                if (x.state === 'missing') continue;
                const ours = x.state === 'modded' || (stamp && stamp.addedSha256 && stamp.addedSha256[f.path] === x.sha);
                if (ours) changes.set(f.path, null);
                else problems.push(`${f.path}: this file is not the mod's`);
                continue;
            }
            if (x.state === 'missing') { problems.push(`${f.path}: not found`); continue; }
            if (x.state === 'vanilla') continue;
            const why = [];
            const out = applyHunks(x.buf.toString('utf8'), f.hunks, true, x.state === 'modded', why);
            if (out === null) { problems.push(`${f.path}: ${why.join('; ')}`); continue; }
            const data = Buffer.from(out, 'utf8');
            if (x.state === 'modded' && sha256(data) !== f.vanillaSha256) { problems.push(`${f.path}: did not undo cleanly`); continue; }
            changes.set(f.path, data);
        }
        if (problems.length) {
            if (trusted) {
                // The player edited the mod's files after installing; the clean backup is still good.
                closeAsar(live);
                restoreBackup(p, stamp);
                say('Mod removed: the original game archive is back. (Changes made to the game files after installing the mod were discarded.) Your saves keep working.');
                return EXIT.OK;
            }
            throw new Abort(['Could not undo the mod\'s edits:', ...problems.map(s => `  - ${s}`), VERIFY_HINT].join('\n'));
        }
        const jobs = fsStep('write the restored game archive', () => writeAsar(live, changes, p.tmp));
        verifyAsar(live, jobs, p.tmp);
        closeAsar(live);
        replaceFile(p.tmp, p.live);
        removeQuietly(p.backup);
        removeQuietly(stampPath(p));
        say('Mod removed: its edits were undone. Your saves keep working.');
        return EXIT.OK;
    } finally {
        closeAsar(live);
        removeQuietly(p.tmp);
    }
}

function main(argv) {
    const flags = new Set(argv.filter(a => a.startsWith('--')));
    const args = argv.filter(a => !a.startsWith('--'));
    const cmd = (args[0] || 'status').toLowerCase();
    const gameDir = path.resolve(args[1] || path.join(__dirname, '..', '..'));
    const manifest = loadManifest();
    say(`${manifest.modName} v${manifest.modVersion}`);
    if (manifest.homepage) say(`Updates and bug reports: ${manifest.homepage}`);
    say('');
    if (cmd === 'install' || cmd === 'uninstall') {
        say(`Game folder: ${gameDir}`);
        say('');
    }
    if (cmd === 'install') return install(gameDir, manifest, flags.has('--force'));
    if (cmd === 'uninstall') return uninstall(gameDir, manifest);
    if (cmd === 'status') return status(gameDir, manifest);
    throw new Abort(`Unknown command "${cmd}". Use install, uninstall or status.`);
}

let code;
try {
    code = main(process.argv.slice(2));
} catch (e) {
    if (e instanceof Abort) { console.log(e.message); code = e.code; } else {
        console.log(`Unexpected error: ${e && e.message || e}`);
        console.log('The game should be unchanged. If it will not start: ' + VERIFY_HINT);
        code = EXIT.FAIL;
    }
}
process.exitCode = code;
