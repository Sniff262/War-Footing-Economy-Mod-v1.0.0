@echo off
title War Footing Economy Mod - Uninstall
if exist "%~dp0mod\run.cmd" goto :run
echo Please extract the whole zip first (right-click it ^> Extract All), then run this file from the extracted folder.
echo.
pause
exit /b 1
:run
"%~dp0mod\run.cmd" uninstall
